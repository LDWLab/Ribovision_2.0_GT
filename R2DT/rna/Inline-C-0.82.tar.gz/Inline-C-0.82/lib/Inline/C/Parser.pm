use strict; use warnings;
package Inline::C::Parser;

1
